import Foundation
// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 10 (Q2 2020) video 13
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Learn the basicis fo Generics
//  For more code, go to http://bit.ly/AppPieGithub


func spellOut<Value:Numeric>(_ value:Value)->String{
    if type(of: value as Any) == type(of:String()){ return value as! String}
    return NumberFormatter.localizedString(from:value as! NSNumber, number: .spellOut)
}

let theAnswer:Int = 42
let shortPi:Float = 3.141
let pi:Double = Double.pi
type(of: theAnswer)
spellOut(pi)
spellOut(theAnswer)
spellOut(shortPi)
//spellOut(false)
//spellOut("Pizza!")
//spellOut([1,3,4])

